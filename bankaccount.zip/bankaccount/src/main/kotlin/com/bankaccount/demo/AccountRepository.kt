package com.bankaccount.demo

import org.springframework.data.mongodb.repository.MongoRepository
import com.sun.el.stream.Optional as Optional


interface AccountRepository: MongoRepository<Account, String>
    fun findByDocument(document: String): java.util.Optional<Account>{}